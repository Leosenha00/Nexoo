import { createApp } from "./app.js";
const server = await createApp();
server.http.listen(Number(process.env.PORT || 3000), "0.0.0.0", () =>
  console.log("Nexo API: http://localhost:3000"),
);
process.on("SIGTERM", async () => {
  await server.close();
  process.exit(0);
});
