export type User = {
  id: string;
  handle: string;
  name: string;
  avatar: string;
  photo?: string | null;
  status: string;
};
export async function api<T = any>(
  url: string,
  method = "GET",
  data?: unknown,
): Promise<T> {
  const r = await fetch("/api" + url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: data === undefined ? undefined : JSON.stringify(data),
  });
  const result = await r
    .json()
    .catch(() => ({ error: "Operação indisponível" }));
  if (!r.ok) throw Error(result.error);
  return result;
}
