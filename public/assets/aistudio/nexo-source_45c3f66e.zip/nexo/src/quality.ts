export const qualities = {
  "720p · 30 FPS": [1280, 720, 30, 2500000],
  "1080p · 30 FPS": [1920, 1080, 30, 5000000],
  "1080p · 60 FPS": [1920, 1080, 60, 8000000],
  "1440p · 60 FPS": [2560, 1440, 60, 12000000],
  "4K · 30 FPS": [3840, 2160, 30, 16000000],
} as const;
export type Quality = keyof typeof qualities;
